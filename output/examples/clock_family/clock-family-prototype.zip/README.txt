Clock family prototype snapshot, 2026-11-18.
Unpack into a separate checkout of Kwentin3/build123d at the code_commit in ACCEPTANCE.json.
See models/clock_family/README.md for assembly, regeneration and physical limitations.
Printable prototype parts: body.stl and portable/lid.stl only; envelope STEP is not a print assembly.
No manufacturing approval, purchases or physical trials.
