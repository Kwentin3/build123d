CAD review input: see models/filter_holder/README.md for the product task. Use the local .agents/skills/cad-entry/SKILL.md.
